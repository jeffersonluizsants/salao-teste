
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getBeautyAdvice = async (userQuery: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userQuery,
      config: {
        systemInstruction: `Você é um consultor de beleza experiente do Salão Lumière. 
        Seu objetivo é ajudar os clientes a escolherem serviços de cabelo, unhas, maquiagem ou pele. 
        Seja elegante, educado e forneça dicas práticas. 
        Mencione serviços como Corte, Coloração, Manicure, Maquiagem e Limpeza de Pele se for relevante.
        Responda em Português do Brasil.`,
        temperature: 0.7,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Desculpe, meu sistema de beleza está passando por um retoque. Tente novamente em instantes!";
  }
};
