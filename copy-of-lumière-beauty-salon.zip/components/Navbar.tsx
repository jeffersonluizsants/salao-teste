
import React from 'react';
import { AuthState, ThemeType } from '../types';

interface NavbarProps {
  auth: AuthState;
  themeStyles: any;
  currentTheme: ThemeType;
  onLogout: () => void;
  onNavigate: (view: 'home' | 'auth' | 'dashboard') => void;
  onToggleTheme: () => void;
  currentView: string;
}

const Navbar: React.FC<NavbarProps> = ({ auth, themeStyles, currentTheme, onLogout, onNavigate, onToggleTheme, currentView }) => {
  return (
    <nav className={`sticky top-0 z-50 backdrop-blur-md border-b ${themeStyles.nav} px-4 md:px-12 py-4 flex items-center justify-between transition-all`}>
      <div 
        className="text-2xl font-serif cursor-pointer tracking-tight flex items-center gap-2"
        onClick={() => onNavigate('home')}
      >
        <span className={themeStyles.accent}>LUMIÈRE</span>
      </div>
      
      <div className="flex items-center space-x-6">
        <button 
          onClick={onToggleTheme}
          className={`p-2 rounded-full border ${themeStyles.border} hover:scale-110 transition`}
          title="Mudar Tema"
        >
          {currentTheme === 'LUXURY' && '✨'}
          {currentTheme === 'LIGHT' && '☀️'}
          {currentTheme === 'CONTRAST' && '👁️'}
        </button>

        <button 
          onClick={() => onNavigate('home')}
          className={`text-sm font-medium transition ${currentView === 'home' ? themeStyles.accent : 'opacity-60 hover:opacity-100'}`}
        >
          Início
        </button>
        
        {auth.isAuthenticated ? (
          <>
            <button 
              onClick={() => onNavigate('dashboard')}
              className={`text-sm font-medium transition ${currentView === 'dashboard' ? themeStyles.accent : 'opacity-60 hover:opacity-100'}`}
            >
              {auth.user?.role === 'OWNER' ? 'Gerência' : 'Minha Agenda'}
            </button>
            <button 
              onClick={onLogout}
              className={`text-sm px-4 py-2 rounded-full border ${themeStyles.border} transition-all`}
            >
              Sair
            </button>
          </>
        ) : (
          <button 
            onClick={() => onNavigate('auth')}
            className={`text-sm px-6 py-2 rounded-full font-bold shadow-lg ${themeStyles.button} transition-all`}
          >
            Acessar
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
