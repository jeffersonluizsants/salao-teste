
import React from 'react';
import { SERVICES } from '../constants';

interface ServicesListProps {
  themeStyles: any;
}

const ServicesList: React.FC<ServicesListProps> = ({ themeStyles }) => {
  return (
    <section className="py-32 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-4xl font-serif mb-4 italic">Assinaturas de Estilo</h2>
        <div className={`w-24 h-1 mx-auto ${themeStyles.button} opacity-40 rounded-full`}></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {SERVICES.map((s) => (
          <div key={s.id} className={`group relative overflow-hidden rounded-[2rem] border transition-all duration-700 hover:-translate-y-4 ${themeStyles.card}`}>
            <div className="h-64 overflow-hidden">
              <img 
                src={s.image} 
                alt={s.name}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition duration-1000 group-hover:scale-110"
              />
            </div>
            <div className="p-8">
              <h3 className="text-xl font-serif mb-2">{s.name}</h3>
              <p className="text-xs opacity-50 mb-6 font-light leading-relaxed">{s.description}</p>
              <div className="flex justify-between items-center pt-4 border-t border-white/5">
                <span className="text-xs uppercase tracking-widest opacity-40">{s.durationMinutes}m</span>
                <span className={`font-bold ${themeStyles.accent}`}>R$ {s.price}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ServicesList;
