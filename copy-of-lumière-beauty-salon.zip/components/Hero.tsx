
import React from 'react';

interface HeroProps {
  themeStyles: any;
  onBook: () => void;
}

const Hero: React.FC<HeroProps> = ({ themeStyles, onBook }) => {
  return (
    <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 opacity-40">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>
        <img 
          src="https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=1920" 
          className="w-full h-full object-cover grayscale"
          alt="Salon background"
        />
      </div>

      <div className="relative z-10 text-center px-4 max-w-5xl">
        <div className="mb-8 flex justify-center">
          <div className={`w-16 h-[1px] ${themeStyles.button} opacity-30`}></div>
          <span className="mx-4 text-xs font-bold uppercase tracking-[0.5em] opacity-80">Since 2025</span>
          <div className={`w-16 h-[1px] ${themeStyles.button} opacity-30`}></div>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-serif mb-8 leading-tight">
          Sua Presença, <br />
          <span className="italic opacity-60">Nosso Arremate.</span>
        </h1>
        
        <p className="text-lg md:text-xl opacity-60 mb-12 max-w-2xl mx-auto font-light tracking-wide">
          Uma experiência de agendamento exclusiva onde o tempo se molda à sua beleza.
        </p>

        <button 
          onClick={onBook}
          className={`px-12 py-5 rounded-full text-sm font-bold uppercase tracking-[0.3em] shadow-[0_20px_50px_rgba(212,175,55,0.2)] hover:scale-105 transition-all duration-300 ${themeStyles.button}`}
        >
          Solicitar Reserva
        </button>
      </div>
    </section>
  );
};

export default Hero;
