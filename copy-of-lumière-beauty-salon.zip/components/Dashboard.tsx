
import React, { useState, useEffect } from 'react';
import { User, Appointment, DetailedRating } from '../types';
import { SERVICES, PROFESSIONALS } from '../constants';
import BookingModal from './BookingModal';
import OwnerAnalytics from './OwnerAnalytics';

interface DashboardProps {
  user: User;
  themeStyles: any;
  allAppointments: Appointment[];
  onAddAppointment: (appt: Appointment) => void;
  onRemoveAppointment: (id: string) => void;
  onUpdateAppointment: (appt: Appointment) => void;
}

const RATING_LABELS: Record<number, string> = {
  1: 'Muito Ruim',
  2: 'Ruim',
  3: 'Regular',
  4: 'Bom',
  5: 'Excelente'
};

const Dashboard: React.FC<DashboardProps> = ({ user, themeStyles, allAppointments, onAddAppointment, onRemoveAppointment, onUpdateAppointment }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [ratingTarget, setRatingTarget] = useState<Appointment | null>(null);
  const [isReviewFlowOpen, setIsReviewFlowOpen] = useState(false);
  
  // Toast state
  const [toast, setToast] = useState<{ message: string; visible: boolean }>({ message: '', visible: false });
  
  const [ratings, setRatings] = useState<DetailedRating>({
    atendimento: 0,
    ambiente: 0,
    qualidade: 0
  });
  const [comment, setComment] = useState('');

  const showToast = (message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast({ message: '', visible: false }), 4000);
  };

  const userAppointments = allAppointments.filter(a => a.userId === user.id);
  
  const upcoming = userAppointments.filter(a => {
    const apptDate = new Date(`${a.date}T${a.time}`);
    return apptDate >= new Date() && !a.detailedRatings && a.status !== 'Cancelado';
  });

  const pastToReview = userAppointments.filter(a => {
    const apptDate = new Date(`${a.date}T${a.time}`);
    return (apptDate < new Date() || a.status === 'Concluído') && !a.detailedRatings && a.status !== 'Cancelado';
  });

  const handleBooking = (serviceId: string, professional: string, date: string, time: string) => {
    const service = SERVICES.find(s => s.id === serviceId);
    if (!service) return;

    const [hours, minutes] = time.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + service.durationMinutes;
    const endH = Math.floor(totalMinutes / 60);
    const endM = totalMinutes % 60;
    const endTime = `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`;

    const newAppt: Appointment = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      serviceId,
      professional,
      date,
      time,
      endTime,
      status: 'Confirmado',
      price: service.price
    };
    onAddAppointment(newAppt);
    setIsModalOpen(false);
    showToast("Reserva confirmada com sucesso! ✨");
  };

  const submitReview = () => {
    if (!ratingTarget) return;
    const totalRating = Math.round((ratings.atendimento + ratings.ambiente + ratings.qualidade) / 3);
    const updated = { 
      ...ratingTarget, 
      rating: totalRating, 
      detailedRatings: ratings, 
      reviewComment: comment 
    };
    onUpdateAppointment(updated);
    setRatingTarget(null);
    setIsReviewFlowOpen(false);
    setComment('');
    setRatings({ atendimento: 0, ambiente: 0, qualidade: 0 });
    showToast("Obrigado pela sua avaliação! 🌟");
  };

  const renderStarCriteria = (category: keyof DetailedRating, title: string) => (
    <div className="space-y-3 bg-black/20 p-4 rounded-2xl border border-white/5">
      <div className="flex justify-between items-center">
        <p className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">{title}</p>
        <span className="text-[10px] opacity-60 italic">
          {ratings[category] > 0 ? RATING_LABELS[ratings[category]] : 'Selecione uma nota'}
        </span>
      </div>
      <div className="flex justify-between gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <div key={star} className="flex flex-col items-center gap-1 group">
            <button 
              onClick={() => setRatings(prev => ({ ...prev, [category]: star }))}
              className={`text-2xl transition-all duration-300 ${star <= ratings[category] ? 'text-[#D4AF37] scale-110 drop-shadow-[0_0_5px_rgba(212,175,55,0.4)]' : 'opacity-20 hover:opacity-50'}`}
            >
              ★
            </button>
            <span className={`text-[7px] uppercase tracking-tighter text-center w-8 leading-none transition-opacity ${star === ratings[category] ? 'opacity-100 font-bold text-[#D4AF37]' : 'opacity-20 group-hover:opacity-100'}`}>
              {RATING_LABELS[star].split(' ')[0]}
            </span>
          </div>
        ))}
      </div>
    </div>
  );

  if (user.role === 'OWNER') {
    return (
      <div className="relative">
        {toast.visible && (
          <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-[200] px-8 py-4 rounded-3xl border shadow-[0_20px_60px_rgba(0,0,0,0.5)] animate-in slide-in-from-bottom-10 fade-in duration-500 flex items-center gap-4 ${themeStyles.card}`}>
            <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">✓</div>
            <p className="text-xs font-bold tracking-widest uppercase">{toast.message}</p>
          </div>
        )}
        <OwnerAnalytics 
          appointments={allAppointments} 
          themeStyles={themeStyles} 
          user={user} 
          onUpdateAppointment={onUpdateAppointment}
          showToast={showToast}
        />
      </div>
    );
  }

  return (
    <div className="py-12 px-4 md:px-12 max-w-6xl mx-auto relative">
      {/* Toast Notification */}
      {toast.visible && (
        <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-[200] px-8 py-4 rounded-3xl border shadow-[0_20px_60px_rgba(0,0,0,0.5)] animate-in slide-in-from-bottom-10 fade-in duration-500 flex items-center gap-4 ${themeStyles.card}`}>
          <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
            ✓
          </div>
          <p className="text-xs font-bold tracking-widest uppercase">{toast.message}</p>
        </div>
      )}

      <div className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-4xl font-serif mb-2">Olá, {user.name}</h1>
          <p className="opacity-60 italic">"Sua beleza, sua luz."</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className={`px-8 py-3 rounded-full font-bold shadow-xl ${themeStyles.button} transition hover:scale-105`}
        >
          + Novo serviço
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        {/* Próximas Visitas */}
        <div className={`p-8 rounded-3xl border ${themeStyles.card}`}>
          <h2 className="text-xl font-serif mb-6 border-b pb-2">Minha Próxima Visita</h2>
          {upcoming.length > 0 ? (
            <div className="space-y-4">
              {upcoming.map(appt => {
                const s = SERVICES.find(x => x.id === appt.serviceId);
                return (
                  <div key={appt.id} className="flex justify-between items-center p-4 border rounded-xl border-white/10 group">
                    <div>
                      <p className="font-bold">{s?.name}</p>
                      <p className="text-xs opacity-50">{appt.date} • {appt.time} - {appt.endTime}</p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className={`text-[10px] font-bold uppercase tracking-widest ${appt.status === 'Confirmado' ? 'text-[#D4AF37]' : 'text-blue-400'}`}>
                        {appt.status}
                      </span>
                      <button 
                        onClick={() => {
                          onUpdateAppointment({ ...appt, status: 'Cancelado' });
                          showToast("Agendamento cancelado.");
                        }}
                        className="text-[10px] uppercase tracking-tighter text-red-500/60 hover:text-red-500 transition-colors font-medium"
                      >
                        Cancelar Agendamento
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="opacity-40 text-center py-10">Nenhum agendamento pendente.</p>
          )}
        </div>

        {/* Seção de Avaliação */}
        <div className={`p-8 rounded-3xl border ${themeStyles.card} relative min-h-[400px] flex flex-col`}>
          <h2 className="text-xl font-serif mb-6 border-b pb-2">Avalie sua Experiência</h2>
          
          {!isReviewFlowOpen ? (
            <div className="flex-grow flex flex-col items-center justify-center text-center space-y-6">
              <div className="relative">
                <div className="absolute inset-0 bg-[#D4AF37]/20 blur-2xl rounded-full"></div>
                <span className="text-6xl relative z-10">✨</span>
              </div>
              
              {pastToReview.length > 0 ? (
                <>
                  <p className="text-sm opacity-60 max-w-[250px]">Você possui serviços realizados aguardando seu feedback!</p>
                  <button 
                    onClick={() => setIsReviewFlowOpen(true)}
                    className={`px-10 py-4 rounded-full font-bold uppercase tracking-[0.2em] text-[10px] shadow-2xl transition-all hover:scale-105 active:scale-95 ${themeStyles.button}`}
                  >
                    Adicionar Avaliação
                  </button>
                </>
              ) : (
                <div className="opacity-40 italic space-y-2">
                  <p className="text-xs">Nada para avaliar por enquanto.</p>
                  <p className="text-[10px]">Sua beleza brilha em cada visita!</p>
                </div>
              )}
            </div>
          ) : !ratingTarget ? (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <p className="text-[10px] uppercase tracking-widest opacity-50 mb-2">Qual serviço deseja avaliar?</p>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {pastToReview.map(appt => {
                  const s = SERVICES.find(x => x.id === appt.serviceId);
                  return (
                    <button 
                      key={appt.id}
                      onClick={() => setRatingTarget(appt)}
                      className="w-full flex justify-between items-center p-4 border rounded-xl border-white/5 bg-white/5 hover:border-[#D4AF37]/50 transition-all text-left group"
                    >
                      <div>
                        <p className="text-sm font-bold group-hover:text-[#D4AF37]">{s?.name}</p>
                        <p className="text-[10px] opacity-50">{appt.date} • {appt.professional}</p>
                      </div>
                      <span className="text-lg opacity-20 group-hover:opacity-100 transition-opacity">→</span>
                    </button>
                  );
                })}
              </div>
              <button 
                onClick={() => setIsReviewFlowOpen(false)}
                className="w-full py-2 text-[10px] uppercase opacity-40 hover:opacity-100 transition"
              >
                Voltar
              </button>
            </div>
          ) : (
            <div className="space-y-6 animate-in zoom-in duration-500">
              <div className="flex items-center gap-4 pb-4 border-b border-white/5">
                <button onClick={() => setRatingTarget(null)} className="opacity-40 hover:opacity-100">←</button>
                <div>
                  <p className="text-xs font-bold">{SERVICES.find(s => s.id === ratingTarget.serviceId)?.name}</p>
                  <p className="text-[9px] opacity-50 uppercase tracking-tighter">Com {ratingTarget.professional}</p>
                </div>
              </div>

              <div className="space-y-4">
                {renderStarCriteria('atendimento', 'Atendimento')}
                {renderStarCriteria('ambiente', 'Ambiente')}
                {renderStarCriteria('qualidade', 'Qualidade')}
              </div>

              <div className="space-y-2">
                <p className="text-[10px] uppercase tracking-widest opacity-40">Seu comentário</p>
                <textarea 
                  placeholder="Conte-nos os detalhes..."
                  className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-xs outline-none focus:border-[#D4AF37] transition-colors min-h-[80px] resize-none"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
              </div>

              <button 
                onClick={submitReview}
                disabled={ratings.atendimento === 0 || ratings.ambiente === 0 || ratings.qualidade === 0}
                className={`w-full py-4 rounded-xl text-[10px] uppercase font-bold tracking-widest shadow-lg transition-all ${
                  (ratings.atendimento === 0 || ratings.ambiente === 0 || ratings.qualidade === 0) 
                  ? 'opacity-20 grayscale cursor-not-allowed' 
                  : themeStyles.button + ' hover:scale-[1.02]'
                }`}
              >
                Confirmar Avaliação
              </button>
            </div>
          )}
        </div>
      </div>

      {isModalOpen && (
        <BookingModal 
          onClose={() => setIsModalOpen(false)} 
          onConfirm={handleBooking}
          existingAppointments={allAppointments}
          themeStyles={themeStyles}
        />
      )}
    </div>
  );
};

export default Dashboard;
