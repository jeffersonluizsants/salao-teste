
import React, { useState, useEffect } from 'react';
import { SERVICES, PROFESSIONALS } from '../constants';
import { Appointment } from '../types';

interface BookingModalProps {
  onClose: () => void;
  onConfirm: (serviceId: string, professional: string, date: string, time: string) => void;
  existingAppointments: Appointment[];
  themeStyles: any;
}

const BookingModal: React.FC<BookingModalProps> = ({ onClose, onConfirm, existingAppointments, themeStyles }) => {
  const [selectedServiceId, setSelectedServiceId] = useState(SERVICES[0].id);
  const [selectedProf, setSelectedProf] = useState(PROFESSIONALS[0]);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [error, setError] = useState<string | null>(null);

  const selectedService = SERVICES.find(s => s.id === selectedServiceId)!;

  // Limpa a seleção de hora se o serviço, profissional ou data mudar
  useEffect(() => {
    setTime('');
    setError(null);
  }, [selectedServiceId, selectedProf, date]);

  // Lógica de detecção de colisão e validade
  const checkCollision = (t: string) => {
    if (!date || !selectedProf) return false;
    
    const now = new Date();
    const selectedDateObj = new Date(date + 'T00:00:00');
    const todayStr = now.toISOString().split('T')[0];

    // 1. Validar se o horário já passou (apenas se for hoje)
    if (date === todayStr) {
      const [h, m] = t.split(':').map(Number);
      const slotTime = new Date();
      slotTime.setHours(h, m, 0, 0);
      if (slotTime < now) return true;
    }

    const [h, m] = t.split(':').map(Number);
    const startM = h * 60 + m;
    const endM = startM + selectedService.durationMinutes;

    // 2. Validar se o serviço termina após o horário de fechamento (ex: 21:00)
    const salonClosingM = 21 * 60;
    if (endM > salonClosingM) return true;

    // 3. Validar colisões com outros agendamentos
    return existingAppointments.some(appt => {
      if (appt.date !== date || appt.professional !== selectedProf) return false;
      
      const [ah, am] = appt.time.split(':').map(Number);
      const [aeh, aem] = appt.endTime.split(':').map(Number);
      
      const apptStartM = ah * 60 + am;
      const apptEndM = aeh * 60 + aem;

      // Condição de sobreposição
      return (startM < apptEndM && endM > apptStartM);
    });
  };

  const handleConfirm = () => {
    if (!date || !time) {
      setError("Por favor, selecione uma data e um horário.");
      return;
    }

    if (checkCollision(time)) {
      setError("Este horário tornou-se indisponível. Escolha outro.");
      setTime('');
      return;
    }

    onConfirm(selectedServiceId, selectedProf, date, time);
  };

  const hours = [];
  for (let h = 8; h <= 20; h++) {
    for (let m = 0; m < 60; m += 30) {
      hours.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className={`relative w-full max-w-2xl rounded-[3rem] border p-8 md:p-12 overflow-hidden animate-in zoom-in duration-500 ${themeStyles.card}`}>
        <h2 className="text-3xl font-serif mb-8 text-center text-[#D4AF37]">Agendamento de Elite</h2>
        
        <div className="space-y-8 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
          <div>
            <p className="text-[10px] uppercase tracking-widest opacity-50 mb-4">1. Selecione a Experiência</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SERVICES.map(s => (
                <button
                  key={s.id}
                  onClick={() => setSelectedServiceId(s.id)}
                  className={`p-4 rounded-2xl border transition-all text-left group ${selectedServiceId === s.id ? themeStyles.button : 'border-white/10 opacity-60 hover:opacity-100 hover:border-white/30'}`}
                >
                  <p className="font-bold text-sm">{s.name}</p>
                  <p className="text-[10px] opacity-70">{s.durationMinutes} min • R$ {s.price}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <p className="text-[10px] uppercase tracking-widest opacity-50 mb-4">2. Artista</p>
              <select 
                className={`w-full bg-transparent border-b p-2 outline-none transition-colors focus:border-[#D4AF37] ${themeStyles.border}`}
                value={selectedProf}
                onChange={(e) => setSelectedProf(e.target.value)}
              >
                {PROFESSIONALS.map(p => <option key={p} className="bg-[#111] text-white" value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest opacity-50 mb-4">3. Data</p>
              <input 
                type="date"
                min={new Date().toISOString().split('T')[0]}
                className={`w-full bg-transparent border-b p-2 outline-none transition-colors focus:border-[#D4AF37] ${themeStyles.border}`}
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
          </div>

          <div>
            <p className="text-[10px] uppercase tracking-widest opacity-50 mb-4">4. Disponibilidade (Slots Livres)</p>
            {!date ? (
              <p className="text-xs italic opacity-30 text-center py-4">Selecione uma data para ver os horários</p>
            ) : (
              <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                {hours.map(h => {
                  const isInvalid = checkCollision(h);
                  return (
                    <button
                      key={h}
                      disabled={isInvalid}
                      onClick={() => setTime(h)}
                      className={`py-2 rounded-lg text-xs font-bold border transition-all ${
                        time === h ? themeStyles.button : 
                        isInvalid ? 'opacity-10 border-red-900 cursor-not-allowed text-red-900 line-through' : 'border-white/10 hover:border-[#D4AF37] opacity-60'
                      }`}
                    >
                      {h}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {error && (
            <div className="bg-red-900/20 border border-red-900/50 p-4 rounded-xl text-red-500 text-xs text-center animate-pulse">
              {error}
            </div>
          )}

          <button
            onClick={handleConfirm}
            disabled={!date || !time}
            className={`w-full py-5 rounded-2xl font-bold uppercase tracking-widest text-xs shadow-2xl transition-all duration-300 ${!date || !time ? 'opacity-20 cursor-not-allowed grayscale' : themeStyles.button + ' hover:scale-[1.02] active:scale-95'}`}
          >
            Confirmar Reserva Lumière
          </button>
        </div>
      </div>
    </div>
  );
};

export default BookingModal;
