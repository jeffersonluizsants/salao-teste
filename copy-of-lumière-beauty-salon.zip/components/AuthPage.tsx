
import React, { useState } from 'react';
import { User, UserRole } from '../types';

interface AuthPageProps {
  onLogin: (user: User) => void;
  themeStyles: any;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin, themeStyles }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [role, setRole] = useState<UserRole>('CLIENT');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isForgotPassword) {
      alert(`Link de recuperação enviado para: ${email}`);
      setIsForgotPassword(false);
      return;
    }

    // Para fins de demonstração, simulamos o objeto de usuário
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: isLogin ? (email.split('@')[0]) : (name || 'Usuário Lumière'),
      email: email || 'lux@lumiere.com',
      role: role,
      theme: 'LUXURY',
      avatar: `https://i.pravatar.cc/150?u=${email}`
    };
    
    onLogin(user);
  };

  const renderForgotPassword = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-serif mb-2 text-[#D4AF37]">Recuperar Acesso</h2>
        <p className="text-xs opacity-50 uppercase tracking-[0.2em]">Informe seu e-mail para receber as instruções</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="group">
          <input 
            type="email" 
            placeholder="Seu E-mail"
            required
            className={`w-full bg-transparent border-b p-3 outline-none focus:border-[#D4AF37] transition-colors ${themeStyles.border}`}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <button 
          type="submit"
          className={`w-full py-5 rounded-2xl font-bold uppercase tracking-widest text-xs shadow-2xl transition-all duration-300 mt-4 active:scale-95 ${themeStyles.button}`}
        >
          Enviar Link de Recuperação
        </button>
      </form>
      <div className="mt-8 text-center">
        <button 
          onClick={() => setIsForgotPassword(false)}
          className="text-[11px] uppercase tracking-[0.2em] opacity-60 hover:opacity-100 transition-opacity flex flex-col items-center gap-2 mx-auto"
        >
          <span className="h-[1px] w-8 bg-current opacity-20"></span>
          Voltar para o Login
        </button>
      </div>
    </div>
  );

  if (isForgotPassword) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-4">
        <div className={`max-w-md w-full rounded-[3rem] border p-12 shadow-2xl transition-all duration-500 ${themeStyles.card}`}>
          {renderForgotPassword()}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className={`max-w-md w-full rounded-[3rem] border p-12 shadow-2xl transition-all duration-500 ${themeStyles.card}`}>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-serif mb-2 text-[#D4AF37]">
            {isLogin ? 'Bem-vinda de volta' : 'Crie sua conta'}
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-[0.2em]">
            {isLogin ? 'Acesse seu portal de beleza' : 'Comece sua jornada de sofisticação'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Seleção de Perfil - Visível apenas no cadastro */}
          {!isLogin && (
            <div className="flex flex-col items-center gap-3 mb-6">
              <span className="text-[10px] uppercase tracking-widest opacity-40">Tipo de Acesso</span>
              <div className="flex justify-center gap-3">
                {(['CLIENT', 'OWNER'] as UserRole[]).map(r => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className={`px-5 py-2 rounded-full text-[10px] font-bold border transition-all duration-300 ${role === r ? themeStyles.button : 'opacity-30 border-white/10'}`}
                  >
                    {r === 'CLIENT' ? 'CLIENTE' : 'FUNCIONÁRIO'}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            {!isLogin && (
              <div className="group">
                <input 
                  type="text" 
                  placeholder="Nome Completo"
                  required={!isLogin}
                  className={`w-full bg-transparent border-b p-3 outline-none focus:border-[#D4AF37] transition-colors ${themeStyles.border}`}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            )}
            
            <div className="group">
              <input 
                type="email" 
                placeholder="Seu E-mail"
                required
                className={`w-full bg-transparent border-b p-3 outline-none focus:border-[#D4AF37] transition-colors ${themeStyles.border}`}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="group">
              <input 
                type="password" 
                placeholder="Senha"
                required
                className={`w-full bg-transparent border-b p-3 outline-none focus:border-[#D4AF37] transition-colors ${themeStyles.border}`}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          {isLogin && (
            <div className="text-right">
              <button 
                type="button" 
                onClick={() => setIsForgotPassword(true)}
                className="text-[10px] uppercase tracking-widest opacity-40 hover:opacity-100 transition"
              >
                Esqueci minha senha
              </button>
            </div>
          )}
          
          <button 
            type="submit"
            className={`w-full py-5 rounded-2xl font-bold uppercase tracking-widest text-xs shadow-2xl transition-all duration-300 mt-4 active:scale-95 ${themeStyles.button}`}
          >
            {isLogin ? 'Entrar no Portal' : 'Finalizar Cadastro'}
          </button>
        </form>

        <div className="mt-10 text-center">
          <button 
            onClick={() => {
              setIsLogin(!isLogin);
              setIsForgotPassword(false);
            }}
            className="text-[11px] uppercase tracking-[0.2em] opacity-60 hover:opacity-100 transition-opacity flex flex-col items-center gap-2 mx-auto"
          >
            <span className="h-[1px] w-8 bg-current opacity-20"></span>
            {isLogin ? 'Não possui uma conta? Cadastre-se' : 'Já é membro? Faça login'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
