
import React, { useState } from 'react';
import { Appointment, User } from '../types';
import { SERVICES, PROFESSIONALS } from '../constants';

interface OwnerAnalyticsProps {
  appointments: Appointment[];
  themeStyles: any;
  user: User;
  onUpdateAppointment: (appt: Appointment) => void;
  showToast: (msg: string) => void;
}

const OwnerAnalytics: React.FC<OwnerAnalyticsProps> = ({ appointments, themeStyles, user, onUpdateAppointment, showToast }) => {
  const [filter, setFilter] = useState<'D' | 'S' | 'M' | 'A'>('M');

  const activeAppts = appointments.filter(a => a.status === 'Concluído');
  const totalRevenue = activeAppts.reduce((acc, curr) => acc + curr.price, 0);
  const totalCount = appointments.length;
  const ticketMedio = totalCount > 0 ? (totalRevenue / totalCount).toFixed(2) : 0;

  // Cálculo de rendimento por funcionário (mês atual)
  const professionalEarnings = PROFESSIONALS.map(prof => {
    const earnings = appointments
      .filter(a => a.professional === prof && a.status === 'Concluído')
      .reduce((acc, curr) => acc + curr.price, 0);
    const count = appointments.filter(a => a.professional === prof && a.status === 'Concluído').length;
    return { name: prof, total: earnings, count };
  }).sort((a, b) => b.total - a.total);

  const handleStatusChange = (appt: Appointment, newStatus: Appointment['status']) => {
    onUpdateAppointment({ ...appt, status: newStatus });
    showToast(`Status atualizado para ${newStatus} ✨`);
  };

  const handleMessage = (appt: Appointment) => {
    // Simulação de envio de mensagem (poderia abrir WhatsApp ou E-mail)
    showToast(`Abrindo chat com o cliente para o serviço de ${SERVICES.find(s => s.id === appt.serviceId)?.name}...`);
  };

  const getStatusStyle = (status: Appointment['status']) => {
    switch (status) {
      case 'Concluído': return 'text-green-500 border-green-500/30 bg-green-500/10';
      case 'Cancelado': return 'text-red-500 border-red-500/30 bg-red-500/10';
      case 'Confirmado': return 'text-blue-400 border-blue-400/30 bg-blue-400/10';
      default: return 'text-yellow-500 border-yellow-500/30 bg-yellow-500/10';
    }
  };

  return (
    <div className="py-12 px-4 md:px-12 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
        <div>
          <span className="text-xs uppercase tracking-[0.3em] opacity-50">Portal Executivo</span>
          <h1 className="text-5xl font-serif mt-2">Gestão Lumière</h1>
        </div>
        
        <div className={`flex rounded-full border ${themeStyles.border} p-1 overflow-hidden`}>
          {['D', 'S', 'M', 'A'].map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-6 py-2 rounded-full text-xs font-bold transition ${filter === f ? themeStyles.button : 'opacity-50'}`}
            >
              {f === 'D' ? 'Dia' : f === 'S' ? 'Sem' : f === 'M' ? 'Mês' : 'Ano'}
            </button>
          ))}
        </div>
      </div>

      {/* KPIs Principais */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className={`p-8 rounded-3xl border ${themeStyles.card} shadow-2xl relative overflow-hidden group`}>
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <svg className="w-20 h-20" fill="currentColor" viewBox="0 0 20 20"><path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" /><path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd" /></svg>
          </div>
          <p className="text-xs opacity-50 uppercase mb-2">Faturamento (Concluído)</p>
          <p className="text-4xl font-serif">R$ {totalRevenue.toLocaleString()}</p>
          <p className="text-xs mt-2 opacity-40">Mês vigente</p>
        </div>
        
        <div className={`p-8 rounded-3xl border ${themeStyles.card} shadow-2xl`}>
          <p className="text-xs opacity-50 uppercase mb-2">Volume de Reservas</p>
          <p className="text-4xl font-serif">{totalCount}</p>
          <p className="text-sm mt-2 text-blue-400">Total acumulado</p>
        </div>

        <div className={`p-8 rounded-3xl border ${themeStyles.card} shadow-2xl`}>
          <p className="text-xs opacity-50 uppercase mb-2">Eficiência Operacional</p>
          <p className="text-4xl font-serif">
            {totalCount > 0 ? ((activeAppts.length / totalCount) * 100).toFixed(0) : 0}%
          </p>
          <p className="text-sm mt-2 opacity-40">Taxa de conclusão</p>
        </div>
      </div>

      {/* Rendimento por Funcionário */}
      <div className="mb-16">
        <h3 className="text-xl font-serif mb-6 flex items-center gap-2">
          <span className="text-[#D4AF37]">✦</span> Desempenho da Equipe
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {professionalEarnings.map(prof => (
            <div key={prof.name} className={`p-6 rounded-2xl border ${themeStyles.card} hover:border-[#D4AF37]/50 transition-all`}>
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-lg">
                  {prof.name.charAt(0)}
                </div>
                <span className="text-[10px] bg-[#D4AF37]/10 text-[#D4AF37] px-2 py-0.5 rounded-full font-bold">
                  {prof.count} serviços
                </span>
              </div>
              <p className="text-sm font-bold truncate">{prof.name}</p>
              <p className={`text-xl font-serif mt-1 ${themeStyles.accent}`}>R$ {prof.total.toLocaleString()}</p>
              <div className="mt-3 h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B]" 
                  style={{ width: `${totalRevenue > 0 ? (prof.total / totalRevenue) * 100 : 0}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gestão de Agendamentos */}
      <div className="overflow-x-auto">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-serif">Gestão de Agendamentos</h3>
        </div>
        <div className={`rounded-3xl border ${themeStyles.card} overflow-hidden`}>
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-[10px] uppercase opacity-40 tracking-widest bg-white/5">
                <th className="p-6">Data/Hora</th>
                <th className="p-6">Serviço / Valor</th>
                <th className="p-6">Profissional</th>
                <th className="p-6">Status</th>
                <th className="p-6 text-right">Ações Rápidas</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {[...appointments].reverse().map(a => {
                const s = SERVICES.find(x => x.id === a.serviceId);
                const isActionable = a.status === 'Confirmado' || a.status === 'Pendente';
                
                return (
                  <tr key={a.id} className="border-b border-white/5 hover:bg-white/5 transition group">
                    <td className="p-6">
                      <p className="font-bold">{a.date}</p>
                      <p className="text-xs opacity-40">{a.time} - {a.endTime}</p>
                    </td>
                    <td className="p-6">
                      <p className="font-bold">{s?.name || 'Serviço'}</p>
                      <p className="text-xs text-[#D4AF37]">R$ {a.price}</p>
                    </td>
                    <td className="p-6 font-medium">{a.professional}</td>
                    <td className="p-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${getStatusStyle(a.status)}`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="p-6 text-right">
                      <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {/* Botão Mensagem - Sempre visível para agendamentos não cancelados */}
                        {a.status !== 'Cancelado' && (
                          <button 
                            onClick={() => handleMessage(a)}
                            className="p-2 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500 hover:text-white transition"
                            title="Mandar Mensagem"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                          </button>
                        )}

                        {isActionable && (
                          <>
                            {a.status === 'Pendente' && (
                              <button 
                                onClick={() => handleStatusChange(a, 'Confirmado')}
                                className="p-2 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500 hover:text-white transition"
                                title="Confirmar Agendamento"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                              </button>
                            )}
                            {a.status === 'Confirmado' && (
                              <button 
                                onClick={() => handleStatusChange(a, 'Concluído')}
                                className="p-2 rounded-lg bg-green-500/20 text-green-500 hover:bg-green-500 hover:text-white transition"
                                title="Marcar como Concluído"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                              </button>
                            )}
                            <button 
                              onClick={() => handleStatusChange(a, 'Cancelado')}
                              className="p-2 rounded-lg bg-red-500/20 text-red-500 hover:bg-red-500 hover:text-white transition"
                              title="Cancelar Agendamento"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                          </>
                        )}
                      </div>
                      {!isActionable && (
                        <span className="text-[10px] opacity-20 uppercase tracking-widest italic pr-2">
                          {a.status === 'Concluído' ? 'Finalizado' : 'Arquivado'}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {appointments.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-12 text-center opacity-30 italic text-sm">
                    Nenhum registro encontrado para o período.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default OwnerAnalytics;
